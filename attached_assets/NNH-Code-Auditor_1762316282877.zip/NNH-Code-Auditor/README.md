# HTML/CSS/JS Replit Extensions Starter

This is an HTML/CSS/JS Extension Starter which includes a few simple API calls.

- [Documentation](https://docs.replit.com/extensions)
- [API Reference](https://docs.replit.com/extensions/category/api-reference)

## Getting Started

1. Fork this Repl if you have not done so already
2. Click the **Extension Devtools** button in the top-right corner of the workspace
3. Under **Tools**, click **Open**
4. Start developing your extension
